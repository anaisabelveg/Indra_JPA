package es.indra;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import es.indra.entities.Escuderia;
import es.indra.entities.Facturacion;
import es.indra.entities.Nif;
import es.indra.entities.Piloto;
import es.indra.entities.Telefono;
import es.indra.entities.Temporada;

public class AppMain{
	
	public static void main(String[] args) {
		
		// Crear el EntityManagerFactory a partir de la unidad de persistencia
		EntityManagerFactory emf = 
				Persistence.createEntityManagerFactory("PU");
		
		// Crear el EntityManager (eje central de JPA)
		// Aqui se abre la conexion a la BBDD
		EntityManager em = emf.createEntityManager();
		
		// Obtener una transaccion
		// JPA obliga a persistir los datos dentro de una transaccion
		EntityTransaction et = em.getTransaction();
		
		
		Escuderia escuderia1 = new Escuderia("Renault", "Francia");
		Escuderia escuderia2 = new Escuderia("Ferrari", "Italia");
		
		Facturacion facturacion1 = new Facturacion(36_000_000, 52_000_000);
		Facturacion facturacion2 = new Facturacion(56_000_000, 16_000_000);
		Facturacion facturacion3 = new Facturacion(46_000_000, 24_000_000);
		Facturacion facturacion4 = new Facturacion(49_000_000, 38_000_000);
		
		Nif nif1 = new Nif('A', 1111111L);
		Nif nif2 = new Nif('B', 2222222L);
		Nif nif3 = new Nif('C', 3333333L);
		Nif nif4 = new Nif('D', 4444444L);
		
		Piloto piloto1 = new Piloto("Alonso", 37, facturacion1, nif1, escuderia1);
		Piloto piloto2 = new Piloto("Massa", 32, facturacion2, nif2, escuderia2);
		Piloto piloto3 = new Piloto("Hamilton", 34, facturacion3, nif3, escuderia1);
		Piloto piloto4 = new Piloto("Schumacher", 41, facturacion4, nif4, escuderia2);
		
		Telefono telefono1 = new Telefono(616111111L);
		Telefono telefono2 = new Telefono(616222222L);
		Telefono telefono3 = new Telefono(616333333L);
		Telefono telefono4 = new Telefono(616444444L);
		Telefono telefono5 = new Telefono(616555555L);
		Telefono telefono6 = new Telefono(616666666L);
		Telefono telefono7 = new Telefono(616777777L);
		Telefono telefono8 = new Telefono(616888888L);
		
		piloto1.addTelefono(telefono1);
		piloto1.addTelefono(telefono2);
		
		piloto2.addTelefono(telefono3);
		piloto2.addTelefono(telefono4);
		
		piloto3.addTelefono(telefono5);
		piloto3.addTelefono(telefono6);
		
		piloto4.addTelefono(telefono7);
		piloto4.addTelefono(telefono8);
		
		Temporada temporada1 = new Temporada(2023, 2024);
		Temporada temporada2 = new Temporada(2024, 2025);
		Temporada temporada3 = new Temporada(2025, 2026);
		
		piloto1.addTemporada(temporada1);
		piloto1.addTemporada(temporada2);
		piloto1.addTemporada(temporada3);
		
		piloto2.addTemporada(temporada1);
		piloto2.addTemporada(temporada2);
		piloto2.addTemporada(temporada3);
		
		piloto3.addTemporada(temporada1);
		piloto3.addTemporada(temporada2);
		
		piloto4.addTemporada(temporada2);
		piloto4.addTemporada(temporada3);
	
		
		try {
			// iniciamos la transaccion
			et.begin();
			
			// Persistimos las 4 entidades a traves del EntityManager
			em.persist(piloto1);
			em.persist(piloto2);
			em.persist(piloto3);
			em.persist(piloto4);
			
			// commit de la transaccion
			et.commit();
			
			// Mostrar un mensaje
			System.out.println("Entidades guardadas en la BBDD");
			
		} catch (Exception e) {
			// ordenar el rollback
			et.rollback();
			
			// mostrar la excepcion
			e.printStackTrace();
			
		} finally {
			// cerrar la conexion
			em.close();
			
			// Cerrar el persistent context
			emf.close(); 
		}
		
	}
	
}