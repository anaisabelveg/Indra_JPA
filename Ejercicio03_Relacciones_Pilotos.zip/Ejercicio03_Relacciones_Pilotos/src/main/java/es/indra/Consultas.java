package es.indra;

import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import es.indra.entities.Escuderia;
import es.indra.entities.Facturacion;
import es.indra.entities.Piloto;
import es.indra.entities.Telefono;

public class Consultas {

	public static void main(String[] args) {
		EntityManagerFactory emf = 
				Persistence.createEntityManagerFactory("PULeer");
		EntityManager em = emf.createEntityManager();
		
		// 1.- Mostrar los pilotos que pertenecen a una determinada temporada
		Query q1 = em.createQuery("select t.pilotos from Temporada t where t.inicio=:ini AND t.fin=:fin");
		q1.setParameter("ini", 2024);
		q1.setParameter("fin", 2025);
	    List<Piloto> lista = q1.getResultList();
	    lista.forEach(System.out::println);
	    System.out.println("-----------------------------------------------");
	    
		
		// 2.- Mostrar los pilotos de una escuderia
		Query q2 = em.createQuery("select e from Escuderia e where e.nombre = :name");
		q2.setParameter("name", "Ferrari");
		Escuderia ferrari = (Escuderia) q2.getSingleResult();
		Set<Piloto> pilotos = ferrari.getPilotos();
		pilotos.forEach(System.out::println);
		System.out.println("-----------------------------------------------");
		
		// 2.- Mostrar lo que ganan en publicidad los pilotos de la escuderia Ferrari y mostrar solo el nombre, la publicidad y sus numeros de telefono
		q2 = em.createQuery("select e from Escuderia e where e.nombre = :name");
		q2.setParameter("name", "Ferrari");
		ferrari = (Escuderia) q2.getSingleResult();
		pilotos = ferrari.getPilotos();
		for (Piloto piloto : pilotos) {
			Facturacion facturacion = piloto.getFacturacion();
			Set<Telefono> telefonos = piloto.getTelefonos();
			System.out.println("Nombre: " + piloto.getNombre() + 
					", Publicidad: " + facturacion.getPublicidad() + ", telefonos: ");
					telefonos.forEach(tel -> System.out.println(tel.getNumero()));
		}
		System.out.println("-----------------------------------------------");
		
		
		// 3.- Mostrar los pilotos con un sueldo superior a una determinada cifra 
		Query q3 = em.createQuery("select p from Piloto p where p.facturacion.sueldo > :cifra"); 
		q3.setParameter("cifra", 48_000_000);
		q3.getResultList().forEach(System.out::println);
	    System.out.println("-----------------------------------------------");
	    
	    
	    // 4.- Mostrar los pilotos que cobren por publicidad entre 2 valores
	    Query q4 = em.createQuery("select p from Piloto p where p.facturacion.publicidad BETWEEN :min AND :max"); 
	    q4.setParameter("min", 20_000_000);
	    q4.setParameter("max", 60_000_000);
	    q4.getResultList().forEach(System.out::println);
	    System.out.println("-----------------------------------------------");
	    
	    
	    // 5.- Mostrar los pilotos que no sean de la escuderia italiana
	    Query q5 = em.createQuery("select p from Piloto p where p.escuderia.pais NOT IN (:pais)");
	    q5.setParameter("pais", "Italia");
	    q5.getResultList().forEach(System.out::println);
	    System.out.println("-----------------------------------------------");
	    
	    
	    // 6.- Mostrar todos los telefonos de Alonso
	    Query q6 = em.createQuery("select t from Telefono t where t.piloto.nombre = :name");
	    q6.setParameter("name", "Alonso");
	    q6.getResultList().forEach(System.out::println);
	    System.out.println("-----------------------------------------------");
	}

}
