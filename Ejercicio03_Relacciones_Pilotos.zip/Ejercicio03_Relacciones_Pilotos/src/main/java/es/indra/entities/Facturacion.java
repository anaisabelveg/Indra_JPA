package es.indra.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Ejercicio03_Facturacion")
public class Facturacion implements Serializable{
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID_FACTURACION", nullable = false, unique = true)
	private Long id;
	
	private int sueldo;
	private int publicidad;
	
	@OneToOne(mappedBy = "facturacion") // La propiedad en Piloto
	private Piloto piloto;
	
	public Facturacion() {
		// TODO Auto-generated constructor stub
	}

	public Facturacion(int sueldo, int publicidad) {
		super();
		this.sueldo = sueldo;
		this.publicidad = publicidad;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public int getSueldo() {
		return sueldo;
	}

	public void setSueldo(int sueldo) {
		this.sueldo = sueldo;
	}

	public int getPublicidad() {
		return publicidad;
	}

	public void setPublicidad(int publicidad) {
		this.publicidad = publicidad;
	}

	public Piloto getPiloto() {
		return piloto;
	}

	public void setPiloto(Piloto piloto) {
		this.piloto = piloto;
	}

	@Override
	public String toString() {
		return "Facturacion [id=" + id + ", sueldo=" + sueldo + ", publicidad=" + publicidad + "]";
	}
	
	

}
