package es.indra.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Ejercicio03_Nifs")
public class Nif implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID_NIF", nullable = false, unique = true)
	private Long id;

	private char letra;
	private long numero;
	
	@OneToOne(mappedBy = "nif")
	private Piloto piloto;

	public Nif() {
		// TODO Auto-generated constructor stub
	}

	public Nif(char letra, long numero) {
		super();
		this.letra = letra;
		this.numero = numero;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public char getLetra() {
		return letra;
	}

	public void setLetra(char letra) {
		this.letra = letra;
	}

	public long getNumero() {
		return numero;
	}

	public void setNumero(long numero) {
		this.numero = numero;
	}

	public Piloto getPiloto() {
		return piloto;
	}

	public void setPiloto(Piloto piloto) {
		this.piloto = piloto;
	}

	@Override
	public String toString() {
		return "Nif [id=" + id + ", letra=" + letra + ", numero=" + numero + "]";
	}

}
