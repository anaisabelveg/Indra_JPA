package es.indra.entities;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Ejercicio03_Pilotos")
public class Piloto implements Serializable{
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID_PILOTO", nullable = false, unique = true)
	private Long id;
	
	private String nombre;
	private int edad;
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "FACTURACION_ID", referencedColumnName = "ID_FACTURACION")
	private Facturacion facturacion;
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "NIF_ID", referencedColumnName = "ID_NIF")
	private Nif nif;
	
	@ManyToOne(cascade = {CascadeType.MERGE, CascadeType.PERSIST, CascadeType.REFRESH})
	@JoinColumn(name = "ESCUDERIA_ID", referencedColumnName = "ID_ESCUDERIA")
	private Escuderia escuderia;
	
	@OneToMany(mappedBy = "piloto", cascade = CascadeType.ALL)
	private Set<Telefono> telefonos = new HashSet<>();
	
	@ManyToMany(cascade = {CascadeType.MERGE, CascadeType.PERSIST, CascadeType.REFRESH})
	@JoinTable(name = "Ejercicio03_Pilotos_Temporadas",
			joinColumns = @JoinColumn(name = "PILOTO_ID", referencedColumnName = "ID_PILOTO"),
			inverseJoinColumns = @JoinColumn(name = "TEMPORADA_ID", referencedColumnName = "ID_TEMPORADA"))
	private Set<Temporada> temporadas  = new HashSet<>();
	
	public Piloto() {
		// TODO Auto-generated constructor stub
	}

	public Piloto(String nombre, int edad, Facturacion facturacion, Nif nif, Escuderia escuderia) {
		super();
		this.nombre = nombre;
		this.edad = edad;
		this.facturacion = facturacion;
		this.nif = nif;
		this.escuderia = escuderia;
	}
	
	// Metodos de sincronizacion
	public void addTelefono(Telefono telefono) {
		telefonos.add(telefono);
		telefono.setPiloto(this);
	}
	
	public void addTemporada(Temporada temporada) {
		temporadas.add(temporada);
		temporada.getPilotos().add(this);
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}

	public Facturacion getFacturacion() {
		return facturacion;
	}

	public void setFacturacion(Facturacion facturacion) {
		this.facturacion = facturacion;
	}

	public Nif getNif() {
		return nif;
	}

	public void setNif(Nif nif) {
		this.nif = nif;
	}

	public Escuderia getEscuderia() {
		return escuderia;
	}

	public void setEscuderia(Escuderia escuderia) {
		this.escuderia = escuderia;
	}

	public Set<Telefono> getTelefonos() {
		return telefonos;
	}

	public void setTelefonos(Set<Telefono> telefonos) {
		this.telefonos = telefonos;
	}

	public Set<Temporada> getTemporadas() {
		return temporadas;
	}

	public void setTemporadas(Set<Temporada> temporadas) {
		this.temporadas = temporadas;
	}

	@Override
	public String toString() {
		return "Piloto [id=" + id + ", nombre=" + nombre + ", edad=" + edad + ", facturacion=" + facturacion + ", nif="
				+ nif + ", escuderia=" + escuderia + ", telefonos=" + telefonos + ", temporadas=" + temporadas + "]";
	}
	
	

}
