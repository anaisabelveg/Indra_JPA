package es.indra.entities;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "Ejercicio03_Escuderias")
public class Escuderia implements Serializable{
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID_ESCUDERIA", nullable = false, unique = true)
	private Long id;
	
	private String nombre;
	private String pais;
	
	@OneToMany(mappedBy = "escuderia", cascade = {CascadeType.MERGE, CascadeType.PERSIST, CascadeType.REFRESH})
	private Set<Piloto> pilotos = new HashSet<>();
	
	public Escuderia() {
		// TODO Auto-generated constructor stub
	}

	public Escuderia(String nombre, String pais) {
		super();
		this.nombre = nombre;
		this.pais = pais;
	}
	
	// Metodo de sincronizacion
	public void addPiloto(Piloto piloto) {
		pilotos.add(piloto);
		piloto.setEscuderia(this);
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getPais() {
		return pais;
	}

	public void setPais(String pais) {
		this.pais = pais;
	}

	public Set<Piloto> getPilotos() {
		return pilotos;
	}

	public void setPilotos(Set<Piloto> pilotos) {
		this.pilotos = pilotos;
	}

	@Override
	public String toString() {
		return "Escuderia [id=" + id + ", nombre=" + nombre + ", pais=" + pais + "]";
	}
	
	

}
