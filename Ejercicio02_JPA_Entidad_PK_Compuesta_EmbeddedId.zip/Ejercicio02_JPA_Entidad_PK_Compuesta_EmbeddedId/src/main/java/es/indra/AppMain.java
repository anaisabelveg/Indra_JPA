package es.indra;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import es.indra.entities.Libro;
import es.indra.entities.LibroPK;

public class AppMain{
	
	public static void main(String[] args) {
		
		// Crear el EntityManagerFactory a partir de la unidad de persistencia
		EntityManagerFactory emf = 
				Persistence.createEntityManagerFactory("PU");
		
		// Crear el EntityManager (eje central de JPA)
		// Aqui se abre la conexion a la BBDD
		EntityManager em = emf.createEntityManager();
		
		// Obtener una transaccion
		// JPA obliga a persistir los datos dentro de una transaccion
		EntityTransaction et = em.getTransaction();
		
	
		try {
			// iniciamos la transaccion
			et.begin();
			
			// Persistimos las 5 entidades a traves del EntityManager
			em.persist(new Libro(new LibroPK("Los pilates de la tierra", "Ken Follet"), "Descripcion 1", "Resumen 1"));
			em.persist(new Libro(new LibroPK("La caida de los gigantes", "Ken Follet"), "Descripcion 2", "Resumen 2"));
			em.persist(new Libro(new LibroPK("El tiempo entre costuras", "Maria Dueñas"), "Descripcion 3", "Resumen 3"));
			em.persist(new Libro(new LibroPK("Como agua para chocolate", "Isabel Allende"), "Descripcion 4", "Resumen 4"));
			em.persist(new Libro(new LibroPK("Mision Olvido", "Maria Dueñas"), "Descripcion 5", "Resumen 5"));
	
			// commit de la transaccion
			et.commit();
			
			// Mostrar un mensaje
			System.out.println("Entidades guardadas en la BBDD");
			
		} catch (Exception e) {
			// ordenar el rollback
			et.rollback();
			
			// mostrar la excepcion
			e.printStackTrace();
			
		} finally {
			// cerrar la conexion
			em.close();
			
			// Cerrar el persistent context
			emf.close(); 
		}
		
	}
	
}