package es.indra.entities;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Lob;
import javax.persistence.Table;

@Entity
@Table(name = "Ejercicio02_Libros_EmbeddedId")
public class Libro implements Serializable {

	@EmbeddedId
	private LibroPK libroPK;

	@Column(name = "DESCRIPCION", length = 50)
	private String descripcion;

	@Lob
	@Basic(fetch = FetchType.LAZY)
	@Column(name = "RESUMEN")
	private String resumen;

	public Libro() {
		// TODO Auto-generated constructor stub
	}

	public Libro(LibroPK libroPK, String descripcion, String resumen) {
		super();
		this.libroPK = libroPK;
		this.descripcion = descripcion;
		this.resumen = resumen;
	}

	public LibroPK getLibroPK() {
		return libroPK;
	}

	public void setLibroPK(LibroPK libroPK) {
		this.libroPK = libroPK;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getResumen() {
		return resumen;
	}

	public void setResumen(String resumen) {
		this.resumen = resumen;
	}

	@Override
	public String toString() {
		return "Libro [libroPK=" + libroPK + ", descripcion=" + descripcion + ", resumen=" + resumen + "]";
	}

}