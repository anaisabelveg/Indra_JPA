package es.indra.entities;

import java.io.Serializable;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class LibroPK implements Serializable {

	@Column(name = "ID_TITULO", length = 50)
	private String titulo;
	
	@Column(name = "ID_AUTOR", length = 20)
	private String autor;

	public LibroPK() {
		// TODO Auto-generated constructor stub
	}

	public LibroPK(String titulo, String autor) {
		super();
		this.titulo = titulo;
		this.autor = autor;
	}

	@Override
	public int hashCode() {
		return Objects.hash(autor, titulo);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		LibroPK other = (LibroPK) obj;
		return Objects.equals(autor, other.autor) && Objects.equals(titulo, other.titulo);
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getAutor() {
		return autor;
	}

	public void setAutor(String autor) {
		this.autor = autor;
	}

	@Override
	public String toString() {
		return "LibroPK [titulo=" + titulo + ", autor=" + autor + "]";
	}

}
