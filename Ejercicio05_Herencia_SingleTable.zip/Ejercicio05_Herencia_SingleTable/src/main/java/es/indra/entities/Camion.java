package es.indra.entities;

import java.io.Serializable;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@DiscriminatorValue(value = "Camion")
public class Camion extends Vehiculo implements Serializable {
	
	private int tara;
	private int pma;
	
	public Camion() {
		// TODO Auto-generated constructor stub
	}

	public Camion(String modelo, float velocidad, int potencia, int tara, int pma) {
		super(modelo, velocidad, potencia);
		this.tara = tara;
		this.pma = pma;
	}

	public int getTara() {
		return tara;
	}

	public void setTara(int tara) {
		this.tara = tara;
	}

	public int getPma() {
		return pma;
	}

	public void setPma(int pma) {
		this.pma = pma;
	}

	@Override
	public String toString() {
		return "Camion [tara=" + tara + ", pma=" + pma + ", toString()=" + super.toString() + "]";
	}
	
	

}
