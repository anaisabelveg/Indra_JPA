package es.indra;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import es.indra.entities.Persona;
import es.indra.models.Direccion;
import es.indra.models.EstadoCivil;

public class AppMain{
	
	public static void main(String[] args) {
		
		// Crear el EntityManagerFactory a partir de la unidad de persistencia
		EntityManagerFactory emf = 
				Persistence.createEntityManagerFactory("PU");
		
		// Crear el EntityManager (eje central de JPA)
		// Aqui se abre la conexion a la BBDD
		EntityManager em = emf.createEntityManager();
		
		// Obtener una transaccion
		// JPA obliga a persistir los datos dentro de una transaccion
		EntityTransaction et = em.getTransaction();
		
		
		// Crear las entidades
		Persona persona1 = new Persona(616111111L, "1111111-A", "Juan", 27, 'V', 1.74F, 
				new Direccion("Ramon y Cajal", 47, "Madrid"), 
				EstadoCivil.SOLTERO, 
				"Medicina en la Universidad Complutense de Madrid en el año 2018 ........");
		
		Persona persona2 = new Persona(616222222L, "2222222-B", "Maria", 32, 'H', 1.65F, 
				new Direccion("Diagonal", 305, "Barcelona"), 
				EstadoCivil.CASADO, 
				"Periodismo en la Universidad Cataluña de Barcelona en el año 2015 ........");
		
		Persona persona3 = new Persona(616333333L, "3333333-C", "Pablo", 59, 'V', 1.70F, 
				new Direccion("Castellana", 128, "Madrid"), 
				EstadoCivil.DIVORCIADO, 
				"Ingeniaria Indrustrial en la Universidad Poliotecnica de Madrid en el año 2007 ........");
		
		Persona persona4 = new Persona(616333333L, "3333333-C", "Pablo", 59, 'V', 1.70F, 
				new Direccion("Castellana", 128, "Madrid"), 
				EstadoCivil.DIVORCIADO, 
				"Ingeniaria Indrustrial en la Universidad Poliotecnica de Madrid en el año 2007 ........");
		
		try {
			// iniciamos la transaccion
			et.begin();
			
			// Persistimos las 3 entidades a traves del EntityManager
			em.persist(persona1);
			em.persist(persona2);
			em.persist(persona3);
			
			// commit de la transaccion
			et.commit();
			
			et.begin();
			// Da error un PK duplicada y solo se ejecuta @PrePersist y no @PostPersist
			em.persist(persona4);
			et.commit();
			
			// Mostrar un mensaje
			System.out.println("Entidades guardadas en la BBDD");
			
		} catch (Exception e) {
			// ordenar el rollback
			et.rollback();
			
			// mostrar la excepcion
			e.printStackTrace();
			
		} finally {
			// cerrar la conexion
			em.close();
			
			// Cerrar el persistent context
			emf.close(); 
		}
		
	}
	
}