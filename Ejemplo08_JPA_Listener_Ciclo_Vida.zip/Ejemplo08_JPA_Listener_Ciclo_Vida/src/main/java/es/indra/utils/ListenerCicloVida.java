package es.indra.utils;

import javax.persistence.PostPersist;
import javax.persistence.PrePersist;

import es.indra.entities.Persona;

public class ListenerCicloVida {
	
	@PrePersist
	public void execute1(Persona persona) {
		persona.setNombre(persona.getNombre().toUpperCase());
		System.out.println("Se va a persistir la entidad " + persona);
	}
	
	@PostPersist
	public void execute2(Persona persona) {
		System.out.println("Se ha persistido la entidad " + persona);
	}

}
