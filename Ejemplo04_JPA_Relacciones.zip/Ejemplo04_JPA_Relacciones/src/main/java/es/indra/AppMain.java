package es.indra;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import es.indra.entities.Coche;
import es.indra.entities.Nif;
import es.indra.entities.Persona;
import es.indra.entities.Telefono;

public class AppMain{
	
	public static void main(String[] args) {
		
		// Crear el EntityManagerFactory a partir de la unidad de persistencia
		EntityManagerFactory emf = 
				Persistence.createEntityManagerFactory("PU");
		
		// Crear el EntityManager (eje central de JPA)
		// Aqui se abre la conexion a la BBDD
		EntityManager em = emf.createEntityManager();
		
		// Obtener una transaccion
		// JPA obliga a persistir los datos dentro de una transaccion
		EntityTransaction et = em.getTransaction();
		
		
		// Crear las entidades
		Persona persona1 = new Persona("Juan", new Nif(1111111L, 'A'));
		Persona persona2 = new Persona("Maria", new Nif(2222222L, 'B'));  
		Persona persona3 = new Persona("Pablo", new Nif(3333333L, 'C'));  
		
		Telefono telefono1 = new Telefono(616111111L);
		Telefono telefono2 = new Telefono(616222222L);
		Telefono telefono3 = new Telefono(616333333L);
		Telefono telefono4 = new Telefono(616444444L);
		Telefono telefono5 = new Telefono(616555555L);
		Telefono telefono6 = new Telefono(616666666L);
		
		Coche coche1 = new Coche("1111-MKT", "A3");
		Coche coche2 = new Coche("2222-MKT", "A4");
		Coche coche3 = new Coche("3333-MKT", "A5");
		Coche coche4 = new Coche("4444-MKT", "A6");
		Coche coche5 = new Coche("5555-MKT", "A7");
		Coche coche6 = new Coche("6666-MKT", "A8");
		Coche coche7 = new Coche("7777-MKT", "Q3");
	
		
		// Asociar los telefonos
		persona1.addTelefono(telefono1);
		persona1.addTelefono(telefono2);
		
		persona2.addTelefono(telefono3);
		persona2.addTelefono(telefono4);
		
		persona3.addTelefono(telefono5);
		persona3.addTelefono(telefono6);
		
		
		// Asociar los coches
		persona1.addCoche(coche1);
		persona1.addCoche(coche4);
		persona1.addCoche(coche5);
		persona1.addCoche(coche7);
		
		persona2.addCoche(coche2);
		persona2.addCoche(coche4);
		persona2.addCoche(coche5);
		persona2.addCoche(coche6);
		
		persona3.addCoche(coche3);
		persona3.addCoche(coche6);
		persona3.addCoche(coche7);
		coche1.addPropietario(persona3);
		
		try {
			// iniciamos la transaccion
			et.begin();
			
			// Persistimos las 3 entidades a traves del EntityManager
			em.persist(persona1);
			em.persist(persona2);
			em.persist(persona3);
			
			// commit de la transaccion
			et.commit();
			
			// Mostrar un mensaje
			System.out.println("Entidades guardadas en la BBDD");
			
		} catch (Exception e) {
			// ordenar el rollback
			et.rollback();
			
			// mostrar la excepcion
			e.printStackTrace();
			
		} finally {
			// cerrar la conexion
			em.close();
			
			// Cerrar el persistent context
			emf.close(); 
		}
		
	}
	
}