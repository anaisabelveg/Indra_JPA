package es.indra.entities;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Ejemplo04_Telefonos")
public class Telefono implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID_TELEFONO")
	private Long id;

	private long numero;

	@ManyToOne(cascade = {CascadeType.MERGE, CascadeType.REFRESH})
	// crear la FK PERSONA_ID. La entidad que tiene la FK es la entidad propietaria
	@JoinColumn(name = "PERSONA_ID" , referencedColumnName = "ID_PERSONA")
	private Persona persona;

	public Telefono() {
		// TODO Auto-generated constructor stub
	}

	public Telefono(long numero) {
		super();
		this.numero = numero;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public long getNumero() {
		return numero;
	}

	public void setNumero(long numero) {
		this.numero = numero;
	}

	public Persona getPersona() {
		return persona;
	}

	public void setPersona(Persona persona) {
		this.persona = persona;
	}

	@Override
	public String toString() {
		return "Telefono [id=" + id + ", numero=" + numero + "]";
	}

}
