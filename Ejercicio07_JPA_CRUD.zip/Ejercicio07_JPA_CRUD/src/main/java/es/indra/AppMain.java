package es.indra;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import es.indra.entities.Producto;
import es.indra.persistence.ProductosDAO;

public class AppMain {

	public static void main(String[] args) {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");

		ProductosDAO dao = new ProductosDAO(emf);
		
		// Crear productos en la BBDD
		Producto producto1 = new Producto("Pantalla", 145.90);
		Producto producto2 = new Producto("Teclado", 48.50);
		Producto producto3 = new Producto("Raton", 19);
		
		dao.insertarProducto(producto1);
		dao.insertarProducto(producto2);
		dao.insertarProducto(producto3);
		
		// Consultar todos 
		dao.consultarTodos().forEach(System.out::println);
		System.out.println("--------------------------------");
		
		// Buscar un producto
		System.out.println("Producto encontrado: " + dao.buscarProducto(2));
		System.out.println("--------------------------------");
		
		// Eliminar el producto 3
		dao.eliminarProducto(3);
		
		// Modificar el producto 1
		Producto modificado = new Producto(1, "Pantalla plana", 138.90);
		System.out.println("Producto modificado: " + dao.modificarProducto(modificado));
		
		// Consultar todos 
		dao.consultarTodos().forEach(System.out::println);
		System.out.println("--------------------------------");
		
		emf.close();

	}

}