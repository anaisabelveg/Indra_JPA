package es.indra.persistence;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import es.indra.entities.Producto;

public class ProductosDAO {

	private EntityManagerFactory emf;

	public ProductosDAO(EntityManagerFactory emf) {
		super();
		this.emf = emf;
	}

	public List<Producto> consultarTodos() {
		EntityManager em = emf.createEntityManager();
		List<Producto> lista = em.createQuery("select p from Producto p").getResultList();
		em.close();
		return lista;
	}

	public Producto buscarProducto(Integer id) {
		EntityManager em = emf.createEntityManager();
		Producto producto = em.find(Producto.class, id);
		em.close();
		return producto;
	}

	public Producto insertarProducto(Producto producto) {
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();
		Producto persistido = null;
		
		try {
			et.begin();
			em.persist(producto);
			et.commit();
				
			CriteriaBuilder cb = em.getCriteriaBuilder();
			CriteriaQuery<Producto> query = cb.createQuery(Producto.class);
			Root<Producto> root = query.from(Producto.class);
			CriteriaQuery<Producto> cqTodos = query.select(root);
			List<Producto> lista = em.createQuery(
					cqTodos.orderBy(cb.desc(root.get("id"))))
						.getResultList();
			persistido = lista.get(0);
			
		} catch (Exception e) {
			et.rollback();
			e.printStackTrace();
		} finally {
			em.close();
		}
		return persistido;
	}

	public void eliminarProducto(Integer id) {
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();
		
		try {
			et.begin();
//			em.createQuery("delete from Producto p where p.id = :codigo")
//				.setParameter("codigo", id)
//				.executeUpdate();
			Producto encontrado = em.find(Producto.class, id);
			if (encontrado != null)
				em.remove(encontrado);
			et.commit();
		} catch (Exception e) {
			et.rollback();
			e.printStackTrace();
		} finally {
			em.close();
		}
	}

	public Producto modificarProducto(Producto modificado) {
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();
		
		try {
			et.begin();
			em.merge(modificado);
			et.commit();
		} catch (Exception e) {
			et.rollback();
			e.printStackTrace();
		} finally {
			em.close();
		}
		return modificado;
		
	}

}
