package es.indra.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Ejercicio01_Personas")
public class Persona implements Serializable {

	@Id // PK simple
	@GeneratedValue(strategy = GenerationType.IDENTITY) // Genera de forma incremental
	@Column(name = "CODIGO", nullable = false, unique = true)
	private Long codigo;

	@Column(name = "NOMBRE", length = 50)
	private String nombre;

	@Column(name = "NIF", length = 20)
	private String nif;

	public Persona() {
		// TODO Auto-generated constructor stub
	}

	public Persona(String nombre, String nif) {
		super();
		this.nombre = nombre;
		this.nif = nif;
	}

	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	public String getNif() {
		return nif;
	}

	public void setNif(String nif) {
		this.nif = nif;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	@Override
	public String toString() {
		return "Persona [codigo=" + codigo + ", nombre=" + nombre + ", nif=" + nif + "]";
	}
	
}