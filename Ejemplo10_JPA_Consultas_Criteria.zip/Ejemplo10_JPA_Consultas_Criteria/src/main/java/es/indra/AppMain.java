package es.indra;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import es.indra.entities.Persona;
import es.indra.models.EstadoCivil;

public class AppMain {

	public static void main(String[] args) {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PULeer");
		EntityManager em = emf.createEntityManager();

		// Objeto que se necesita para crear consultas con Criteria
		CriteriaBuilder cb = em.getCriteriaBuilder();
		
		// Seleccionamos la entidad a consultar
		CriteriaQuery<Persona> query = cb.createQuery(Persona.class);
		Root<Persona> persona = query.from(Persona.class);
		
		// Todas las personas
		CriteriaQuery<Persona> cqTodos = query.select(persona);
		em.createQuery(cqTodos).getResultList().forEach(System.out::println);
		
		// Otra forma de hacerlo todo en la misma linea
		//em.createQuery(query.select(persona)).getResultList().forEach(System.out::println);
		
		System.out.println("------------------------------------------------");
		
		// Mostrar todas las personas por edad descendente
		em.createQuery(
				cqTodos.orderBy(cb.desc(persona.get("edad"))))
					.getResultList().forEach(System.out::println);
		System.out.println("------------------------------------------------");
		
		// Mostrar todas las personas por altura ascendente
		em.createQuery(
				cqTodos.orderBy(cb.asc(persona.get("altura"))))
					.getResultList().forEach(System.out::println);
		System.out.println("------------------------------------------------");
		
		// Empezamos a filtrar, buscar por nombre = Maria
		Predicate condicion = cb.equal(persona.get("nombre"),  "Maria");
		CriteriaQuery<Persona> cqNombre = cqTodos.where(condicion);
		em.createQuery(cqNombre).getResultList().forEach(System.out::println);
		System.out.println("------------------------------------------------");
		
		// Mostrar a todos los varones
		condicion = cb.equal(persona.get("sexo"),  'V');
		CriteriaQuery<Persona> cqSexo = cqTodos.where(condicion);
		em.createQuery(cqSexo).getResultList().forEach(System.out::println);
		System.out.println("------------------------------------------------");
		
		// Mostrar todas las personas entre un rango de edad
		condicion = cb.between(persona.get("edad"), 20, 40 );
		CriteriaQuery<Persona> cqEdad = cqTodos.where(condicion);
		em.createQuery(cqEdad).getResultList().forEach(System.out::println);
		System.out.println("------------------------------------------------");
		
		em.createQuery(
				cqTodos.where(cb.between(persona.get("edad"), 20, 40 )))
					.getResultList().forEach(System.out::println);
		System.out.println("------------------------------------------------");
		
		// Mostrar todas las personas cuyo nombre comiencen por J
		em.createQuery(
				cqTodos.where(cb.like(persona.get("nombre"), "J%" )))
					.getResultList().forEach(System.out::println);
		System.out.println("------------------------------------------------");
		
		// Mostrar todas las personas cuyo nombre contengan la letra u o la letra o
		em.createQuery(
				cqTodos.where(cb.or(
							    cb.like(persona.get("nombre"), "%u%"),
							    cb.like(persona.get("nombre"), "%o%")
						)))
					.getResultList().forEach(System.out::println);
		System.out.println("------------------------------------------------");
		
		// Mostrar todas las personas cuyo nombre contengan la letra u mayuscula o minuscula
		em.createQuery(
				cqTodos.where(cb.like(cb.lower(persona.get("nombre")), "%u%")))
					.getResultList().forEach(System.out::println);
		System.out.println("------------------------------------------------");
		
		
		// Mostrar las personas que viven en Madrid
		em.createQuery(
				cqTodos.where(cb.equal(persona.get("direccion").get("poblacion"), "Madrid" )))
					.getResultList().forEach(System.out::println);
		System.out.println("------------------------------------------------");
		
		// Mostrar los solteros o divorciados
		em.createQuery(
				cqTodos.where(
						persona.get("estado").in(EstadoCivil.SOLTERO, EstadoCivil.DIVORCIADO)))
					.getResultList().forEach(System.out::println);
		System.out.println("------------------------------------------------");
		
		// Cuidado con los tipos float o doubles que no son exactos
		// En este caso no me filtra por altura mayor a 1.70 sino que aplica mayor o igual
		// Mostrar las personas con una altura mayor que 1.70
		em.createQuery(
				cqTodos.where(
						cb.greaterThan(persona.get("altura"), 1.7F)))
					.getResultList().forEach(System.out::println);
		System.out.println("------------------------------------------------");
		
		// Mostrar las personas con una altura mayor o igual que 1.70
		em.createQuery(
				cqTodos.where(
						cb.greaterThanOrEqualTo(persona.get("altura"), 1.7F)))
					.getResultList().forEach(System.out::println);
		System.out.println("------------------------------------------------");
		
		
		// Mostrar las personas mayor de 32 años
		em.createQuery(
				cqTodos.where(
						cb.greaterThan(persona.get("edad"), 32)))
					.getResultList().forEach(System.out::println);
		System.out.println("------------------------------------------------");
		
		// Mostrar las personas mayor o igual de 32 años
		em.createQuery(
				cqTodos.where(
						cb.greaterThanOrEqualTo(persona.get("edad"), 32)))
					.getResultList().forEach(System.out::println);
		System.out.println("------------------------------------------------");
	
		
		
		


		em.close();
		emf.close();

	}

}