package es.indra.entities;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.SecondaryTable;
import javax.persistence.Table;

import es.indra.models.Direccion;
import es.indra.models.EstadoCivil;

@Entity
@Table(name = "Ejemplo03_Personas")
@SecondaryTable(name = "Ejemplo03_CV", pkJoinColumns = {
		@PrimaryKeyJoinColumn(name = "ID_NIF", referencedColumnName = "ID_NIF"),
		@PrimaryKeyJoinColumn(name = "ID_TELEFONO", referencedColumnName = "ID_TELEFONO") })
public class Persona implements Serializable {

	//@Id Tambien funciona
	@EmbeddedId
	private PersonaPK personaPK;

	@Column(name = "NOMBRE", length = 50)
	private String nombre;

	private int edad;

	@Column(length = 1)
	private char sexo;

	private float altura;

	@Embedded
	private Direccion direccion;

	@Enumerated(EnumType.STRING)
	private EstadoCivil estado;

	@Column(table = "Ejemplo03_CV")
	@Lob
	@Basic(fetch = FetchType.LAZY)
	private String curriculum;

	public Persona() {
		// TODO Auto-generated constructor stub
	}

	public Persona(PersonaPK personaPK, String nombre, int edad, char sexo, float altura, Direccion direccion,
			EstadoCivil estado, String curriculum) {
		super();
		this.personaPK = personaPK;
		this.nombre = nombre;
		this.edad = edad;
		this.sexo = sexo;
		this.altura = altura;
		this.direccion = direccion;
		this.estado = estado;
		this.curriculum = curriculum;
	}

	public PersonaPK getPersonaPK() {
		return personaPK;
	}

	public void setPersonaPK(PersonaPK personaPK) {
		this.personaPK = personaPK;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}

	public char getSexo() {
		return sexo;
	}

	public void setSexo(char sexo) {
		this.sexo = sexo;
	}

	public float getAltura() {
		return altura;
	}

	public void setAltura(float altura) {
		this.altura = altura;
	}

	public Direccion getDireccion() {
		return direccion;
	}

	public void setDireccion(Direccion direccion) {
		this.direccion = direccion;
	}

	public EstadoCivil getEstado() {
		return estado;
	}

	public void setEstado(EstadoCivil estado) {
		this.estado = estado;
	}

	public String getCurriculum() {
		return curriculum;
	}

	public void setCurriculum(String curriculum) {
		this.curriculum = curriculum;
	}

	@Override
	public String toString() {
		return "Persona [personaPK=" + personaPK + ", nombre=" + nombre + ", edad=" + edad + ", sexo=" + sexo
				+ ", altura=" + altura + ", direccion=" + direccion + ", estado=" + estado + ", curriculum="
				+ curriculum + "]";
	}


}