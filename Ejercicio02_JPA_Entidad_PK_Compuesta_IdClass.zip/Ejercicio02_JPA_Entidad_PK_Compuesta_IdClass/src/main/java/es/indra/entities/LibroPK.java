package es.indra.entities;

import java.io.Serializable;
import java.util.Objects;

public class LibroPK implements Serializable {

	private String titulo;
	private String autor;

	public LibroPK() {
		// TODO Auto-generated constructor stub
	}

	public LibroPK(String titulo, String autor) {
		super();
		this.titulo = titulo;
		this.autor = autor;
	}

	@Override
	public int hashCode() {
		return Objects.hash(autor, titulo);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		LibroPK other = (LibroPK) obj;
		return Objects.equals(autor, other.autor) && Objects.equals(titulo, other.titulo);
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getAutor() {
		return autor;
	}

	public void setAutor(String autor) {
		this.autor = autor;
	}

	@Override
	public String toString() {
		return "LibroPK [titulo=" + titulo + ", autor=" + autor + "]";
	}

}
