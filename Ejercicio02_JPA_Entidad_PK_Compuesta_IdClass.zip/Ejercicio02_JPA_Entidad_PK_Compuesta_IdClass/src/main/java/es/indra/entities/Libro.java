package es.indra.entities;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Lob;
import javax.persistence.Table;

@Entity
@IdClass(LibroPK.class)
@Table(name = "Ejercicio02_Libros")
public class Libro implements Serializable {

	@Id // PK compuesta
	@Column(name = "ID_TITULO", length = 50)
	private String titulo;

	@Id // PK compuesta
	@Column(name = "ID_AUTOR", length = 20)
	private String autor;

	@Column(name = "DESCRIPCION", length = 50)
	private String descripcion;

	@Lob
	@Basic(fetch = FetchType.LAZY)
	@Column(name = "RESUMEN")
	private String resumen;

	public Libro() {
		// TODO Auto-generated constructor stub
	}

	public Libro(String titulo, String autor, String descripcion, String resumen) {
		super();
		this.titulo = titulo;
		this.autor = autor;
		this.descripcion = descripcion;
		this.resumen = resumen;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getAutor() {
		return autor;
	}

	public void setAutor(String autor) {
		this.autor = autor;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getResumen() {
		return resumen;
	}

	public void setResumen(String resumen) {
		this.resumen = resumen;
	}

	@Override
	public String toString() {
		return "Libro [titulo=" + titulo + ", autor=" + autor + ", descripcion=" + descripcion + ", resumen=" + resumen
				+ "]";
	}

}