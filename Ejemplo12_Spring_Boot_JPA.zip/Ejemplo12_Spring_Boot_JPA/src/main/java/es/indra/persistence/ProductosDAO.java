package es.indra.persistence;

import org.springframework.data.jpa.repository.JpaRepository;

import es.indra.entities.Producto;

// En Spring Boot todas las interface que heredan de xxxRepository se consideran un bean de bean
public interface ProductosDAO extends JpaRepository<Producto, Integer>{

}
