package es.indra.business;

import java.util.List;

import es.indra.entities.Producto;

public interface IProductosBS {
	
	public List<Producto> consultarTodos();
	
	public Producto buscarProducto(Integer id);
	
	public Producto insertarProducto(Producto producto);
	
	public void eliminarProducto(Integer id);
	
	public Producto modificarProducto(Producto modificado);

}
