package es.indra.business;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import es.indra.entities.Producto;
import es.indra.persistence.ProductosDAO;

@Service   // Genera un bean de esta clase
public class ProductosBSImpl implements IProductosBS{
	
	@Autowired  // Inyectar el bean de tipo ProductosDAO
	private ProductosDAO dao;

	@Override
	public List<Producto> consultarTodos() {
		return dao.findAll();
	}

	@Override
	public Producto buscarProducto(Integer id) {
		return dao.findById(id).orElse(new Producto());
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED,
			isolation = Isolation.SERIALIZABLE,
			rollbackFor = Exception.class)
	public Producto insertarProducto(Producto producto) {
		return dao.save(producto);
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED,
			isolation = Isolation.SERIALIZABLE,
			rollbackFor = Exception.class)
	public void eliminarProducto(Integer id) {
		dao.deleteById(id);
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED,
			isolation = Isolation.SERIALIZABLE,
			rollbackFor = Exception.class)
	public Producto modificarProducto(Producto modificado) {
		return dao.save(modificado);
	}

}
