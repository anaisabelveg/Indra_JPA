package es.indra;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ejemplo12SpringBootJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo12SpringBootJpaApplication.class, args);
	}

}
