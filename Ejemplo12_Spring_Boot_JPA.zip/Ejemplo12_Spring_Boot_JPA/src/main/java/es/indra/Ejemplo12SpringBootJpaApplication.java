package es.indra;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import es.indra.business.IProductosBS;
import es.indra.entities.Producto;

@SpringBootApplication
public class Ejemplo12SpringBootJpaApplication implements CommandLineRunner {
	
	// Busca un bean del tipo IProductosBS y lo inyecta
	@Autowired
	private IProductosBS bs;

	public static void main(String[] args) {
		// Este metodo main esta dedicado exclusivamente a levantar el contexto de
		// Spring
		SpringApplication.run(Ejemplo12SpringBootJpaApplication.class, args);
	}

	// Este metodo se ejecuta automaticamente a partir del metodo main
	@Override
	public void run(String... args) throws Exception {
		// Crear productos en la BBDD
		Producto producto1 = new Producto("Pantalla", 145.90);
		Producto producto2 = new Producto("Teclado", 48.50);
		Producto producto3 = new Producto("Raton", 19);

		bs.insertarProducto(producto1);
		bs.insertarProducto(producto2);
		bs.insertarProducto(producto3);

		// Consultar todos
		bs.consultarTodos().forEach(System.out::println);
		System.out.println("--------------------------------");

		// Buscar un producto
		System.out.println("Producto encontrado: " + bs.buscarProducto(2));
		System.out.println("--------------------------------");

		// Eliminar el producto 3
		bs.eliminarProducto(3);

		// Modificar el producto 1
		Producto modificado = new Producto(1, "Pantalla plana", 138.90);
		System.out.println("Producto modificado: " + bs.modificarProducto(modificado));

		// Consultar todos
		bs.consultarTodos().forEach(System.out::println);
		System.out.println("--------------------------------");

	}

}
