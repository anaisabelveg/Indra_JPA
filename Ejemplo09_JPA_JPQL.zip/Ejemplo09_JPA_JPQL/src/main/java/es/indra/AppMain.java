package es.indra;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import es.indra.entities.Persona;
import es.indra.models.EstadoCivil;

public class AppMain {

	public static void main(String[] args) {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PULeer");
		EntityManager em = emf.createEntityManager();

		// 1.- Buscar una entidad por su PK
		// Si fuese una PK compuesta generamos una instancia de PersonaPK
		String pk = "2222222-B";
		Persona persona = em.find(Persona.class, pk);   // find solo te busca por PK
		System.out.println(persona);
		System.out.println("------------------------------------------------");
		
		// 2.- Consultas por JPQL
		// Mostramos todas las personas con todos sus atributos
		String consulta = "select p from Persona p";
		Query query = em.createQuery(consulta);
		List<Persona> todas = query.getResultList();
		todas.forEach(System.out::println);
		System.out.println("------------------------------------------------");
		
		// Mostramos todas las personas pero solo su nombre y edad
		consulta = "select p.nombre, p.edad from Persona p";
		query = em.createQuery(consulta);
		List<Object[]> personas =  query.getResultList();
		personas.forEach(obj -> System.out.println(obj[0] + ", " + obj[1]));
		System.out.println("------------------------------------------------");
		
		// Mostramos todas las personas mayor de 30 años
		consulta = "select p from Persona p where p.edad > 30";
		query = em.createQuery(consulta);
		query.getResultList().forEach(System.out::println);
		System.out.println("------------------------------------------------");
		
		// Mostramos todas las personas mayor de 30 años y varon
		consulta = "select p from Persona p where p.edad > 30 and p.sexo = 'V' ";
		query = em.createQuery(consulta);
		query.getResultList().forEach(System.out::println);
		System.out.println("------------------------------------------------");
		
		// Mostramos todas las personas mayor de 30 años y varon con parametros
		consulta = "select p from Persona p where p.edad > :age and p.sexo = :sex ";
		query = em.createQuery(consulta);
		query.setParameter("age", 30);
		query.setParameter("sex", 'V');
		query.getResultList().forEach(System.out::println);
		System.out.println("------------------------------------------------");
		
		
		// 3.- Lecturas por NamedQuery
		query = em.createNamedQuery("todas");
		query.getResultList().forEach(System.out::println);
		System.out.println("------------------------------------------------");
		
		query = em.createNamedQuery("estadoCivil");
		query.setParameter("param", EstadoCivil.SOLTERO);
		query.getResultList().forEach(System.out::println);	
		System.out.println("------------------------------------------------");
		
		query = em.createNamedQuery("nombre");
		query.setParameter("param", "%" + "o" + "%");
		query.getResultList().forEach(System.out::println);	
		System.out.println("------------------------------------------------");
		
		query = em.createNamedQuery("edad");
		query.setParameter("min", 20);
		query.setParameter("max", 50);
		query.getResultList().forEach(System.out::println);	
		System.out.println("------------------------------------------------");
		
		
		// 4.- Consultas a través de procedimientos almacenados en la BBDD
		query = em.createNamedStoredProcedureQuery("ProcedimientoBuscarPorNombre");
		query.setParameter("p_nombre", "Maria");
		query.getResultList().forEach(System.out::println);	
		System.out.println("------------------------------------------------");
		
		// 5.- Consultas por SQL (NativeQuery)
		query = em.createNativeQuery("select * from Ejemplo09_Personas");
		List<Object[]> resultados = query.getResultList();
		for (Object[] registro : resultados) {
			System.out.println(Arrays.toString(registro));
		}
		System.out.println("------------------------------------------------");
		
		query = em.createNativeQuery("select NOMBRE, edad from Ejemplo09_Personas");
		resultados = query.getResultList();
		for (Object[] registro : resultados) {
			//System.out.println(Arrays.toString(registro));
			System.out.println("Nombre: " + registro[0] + ", Edad: " + registro[1]);
		}
		System.out.println("------------------------------------------------");
		
		query = em.createNamedQuery("sql");
		resultados = query.getResultList();
		for (Object[] registro : resultados) {
			//System.out.println(Arrays.toString(registro));
			System.out.println("Nombre: " + registro[0] + ", Edad: " + registro[1]);
		}
		System.out.println("------------------------------------------------");
		
		query = em.createNamedQuery("sqlEdad");
		query.setParameter("age", 30);   // Parametro nombrado
		resultados = query.getResultList();
		for (Object[] registro : resultados) {
			System.out.println("Nombre: " + registro[0] + ", Edad: " + registro[1]);
		}
		System.out.println("------------------------------------------------");
		
		query = em.createNamedQuery("sqlEdad2");
		query.setParameter(1, 30);    // Parametro con ?
		resultados = query.getResultList();
		for (Object[] registro : resultados) {
			System.out.println("Nombre: " + registro[0] + ", Edad: " + registro[1]);
		}
		System.out.println("------------------------------------------------");
		

		em.close();
		emf.close();

	}

}