package es.indra;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import es.indra.entities.Alumno;
import es.indra.entities.Persona;
import es.indra.entities.Profesor;

public class AppMain{
	
	public static void main(String[] args) {
		
		// Crear el EntityManagerFactory a partir de la unidad de persistencia
		EntityManagerFactory emf = 
				Persistence.createEntityManagerFactory("PU");
		
		// Crear el EntityManager (eje central de JPA)
		// Aqui se abre la conexion a la BBDD
		EntityManager em = emf.createEntityManager();
		
		// Obtener una transaccion
		// JPA obliga a persistir los datos dentro de una transaccion
		EntityTransaction et = em.getTransaction();
		
		
		// Crear las entidades
		Persona persona = new Persona("Juan", "Lopez");		
		Alumno alumno = new Alumno("Maria", "Gutierrez", "JPA", 8.3);
		Profesor profesor = new Profesor("Pedro", "Rodriguez", "Ingeniero Teleco", true);
		
		try {
			// iniciamos la transaccion
			et.begin();
			
			// Persistimos las 3 entidades a traves del EntityManager
			em.persist(persona);
			em.persist(alumno);
			em.persist(profesor);
			
			// commit de la transaccion
			et.commit();
			
			// Mostrar un mensaje
			System.out.println("Entidades guardadas en la BBDD");
			
		} catch (Exception e) {
			// ordenar el rollback
			et.rollback();
			
			// mostrar la excepcion
			e.printStackTrace();
			
		} finally {
			// cerrar la conexion
			em.close();
			
			// Cerrar el persistent context
			emf.close(); 
		}
		
	}
	
}