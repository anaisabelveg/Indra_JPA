package es.indra.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Ejemplo06_Profesores_Joined")
@DiscriminatorValue(value = "Profe")
public class Profesor extends Persona implements Serializable {

	@Column(name = "TITULACION", length = 50)
	private String titulacion;

	@Column(name = "HOMOLOGADO", length = 50)
	private boolean homologado;

	public Profesor() {
		// TODO Auto-generated constructor stub
	}

	public Profesor(String nombre, String apellido, String titulacion, boolean homologado) {
		super(nombre, apellido);
		this.titulacion = titulacion;
		this.homologado = homologado;
	}

	public String getTitulacion() {
		return titulacion;
	}

	public void setTitulacion(String titulacion) {
		this.titulacion = titulacion;
	}

	public boolean isHomologado() {
		return homologado;
	}

	public void setHomologado(boolean homologado) {
		this.homologado = homologado;
	}

	@Override
	public String toString() {
		return "Profesor [titulacion=" + titulacion + ", homologado=" + homologado + ", toString()=" + super.toString()
				+ "]";
	}

}