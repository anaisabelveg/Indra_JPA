package es.indra.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Ejemplo06_Alumnos_Joined")
@DiscriminatorValue(value = "Alum")
public class Alumno extends Persona implements Serializable {

	@Column(name = "CURSO", length = 50)
	private String curso;

	@Column(name = "NOTA")
	private double nota;

	public Alumno() {
		// TODO Auto-generated constructor stub
	}

	public Alumno(String nombre, String apellido, String curso, double nota) {
		super(nombre, apellido);
		this.curso = curso;
		this.nota = nota;
	}

	public String getCurso() {
		return curso;
	}

	public void setCurso(String curso) {
		this.curso = curso;
	}

	public double getNota() {
		return nota;
	}

	public void setNota(double nota) {
		this.nota = nota;
	}

	@Override
	public String toString() {
		return "Alumno [curso=" + curso + ", nota=" + nota + ", toString()=" + super.toString() + "]";
	}

}