package es.indra.config;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

import es.indra.persistence.ProductosDAO;

@Configuration
public class JavaConfig {
	
	@Bean   // Convierte el objeto Java que retorna este metodo en un bean de Spring
	@Scope("prototype")
	public EntityManagerFactory emf() {
		return Persistence.createEntityManagerFactory("PU");
	}
	
	@Bean
	// El nombre del metodo es el id del bean
	public ProductosDAO dao() {
		ProductosDAO dao = new ProductosDAO();
		dao.setEmf(emf());
		return dao;
	}

}
