package es.indra;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import es.indra.entities.Camion;
import es.indra.entities.Coche;
import es.indra.entities.Vehiculo;

public class AppMain{
	
	public static void main(String[] args) {
		
		// Crear el EntityManagerFactory a partir de la unidad de persistencia
		EntityManagerFactory emf = 
				Persistence.createEntityManagerFactory("PU");
		
		// Crear el EntityManager (eje central de JPA)
		// Aqui se abre la conexion a la BBDD
		EntityManager em = emf.createEntityManager();
		
		// Obtener una transaccion
		// JPA obliga a persistir los datos dentro de una transaccion
		EntityTransaction et = em.getTransaction();
		
		
		// Crear las entidades
		Coche coche = new Coche(1L, "A6", 180F, 150, 5, 4.22F);
		Camion camion = new Camion(2L, "IBECO 300", 140F, 300, 4000, 25_000);
		Vehiculo vehiculo = new Vehiculo(3L, "Tractor", 20F, 100);
		
		try {
			// iniciamos la transaccion
			et.begin();
			
			// Persistimos las 3 entidades a traves del EntityManager
			em.persist(coche);
			em.persist(camion);
			em.persist(vehiculo);
			
			// commit de la transaccion
			et.commit();
			
			// Mostrar un mensaje
			System.out.println("Entidades guardadas en la BBDD");
			
		} catch (Exception e) {
			// ordenar el rollback
			et.rollback();
			
			// mostrar la excepcion
			e.printStackTrace();
			
		} finally {
			// cerrar la conexion
			em.close();
			
			// Cerrar el persistent context
			emf.close(); 
		}
		
	}
	
}