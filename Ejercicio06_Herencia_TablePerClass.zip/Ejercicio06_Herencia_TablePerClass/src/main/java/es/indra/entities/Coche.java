package es.indra.entities;

import java.io.Serializable;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "Ejercicio06_Coches_TablePerClass")
public class Coche extends Vehiculo implements Serializable {

	private int puertas;
	private float longitud;

	public Coche() {
		// TODO Auto-generated constructor stub
	}

	public Coche(Long id, String modelo, float velocidad, int potencia, int puertas, float longitud) {
		super(id, modelo, velocidad, potencia);
		this.puertas = puertas;
		this.longitud = longitud;
	}

	public int getPuertas() {
		return puertas;
	}

	public void setPuertas(int puertas) {
		this.puertas = puertas;
	}

	public float getLongitud() {
		return longitud;
	}

	public void setLongitud(float longitud) {
		this.longitud = longitud;
	}

	@Override
	public String toString() {
		return "Coche [puertas=" + puertas + ", longitud=" + longitud + ", toString()=" + super.toString() + "]";
	}

}
