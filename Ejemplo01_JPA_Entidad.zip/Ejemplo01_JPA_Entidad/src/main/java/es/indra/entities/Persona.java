package es.indra.entities;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.SecondaryTable;
import javax.persistence.Table;

import es.indra.models.Direccion;
import es.indra.models.EstadoCivil;

@Entity
@Table(name = "Ejemplo01_Personas")
@SecondaryTable(name = "Ejemplo01_CV",
				pkJoinColumns = @PrimaryKeyJoinColumn(name = "ID_NIF", referencedColumnName = "ID_NIF") )
public class Persona implements Serializable{
	
	private Long telefono;
	
	@Id  // PK simple
	@Column(name = "ID_NIF")
	private String nif;
	
	@Column(name = "NOMBRE", length = 50)
	private String nombre;
	
	private int edad;
	
	@Column(length = 1)
	private char sexo;
	
	private float altura;
	
	@Embedded
	private Direccion direccion;
	
	@Enumerated(EnumType.STRING)
	private EstadoCivil estado;
	
	@Column(table = "Ejemplo01_CV")
	@Lob
	@Basic(fetch = FetchType.LAZY)
	private String curriculum;
	
	
	public Persona() {
		// TODO Auto-generated constructor stub
	}


	public Persona(Long telefono, String nif, String nombre, int edad, char sexo, float altura, Direccion direccion,
			EstadoCivil estado, String curriculum) {
		super();
		this.telefono = telefono;
		this.nif = nif;
		this.nombre = nombre;
		this.edad = edad;
		this.sexo = sexo;
		this.altura = altura;
		this.direccion = direccion;
		this.estado = estado;
		this.curriculum = curriculum;
	}


	public Long getTelefono() {
		return telefono;
	}


	public void setTelefono(Long telefono) {
		this.telefono = telefono;
	}


	public String getNif() {
		return nif;
	}


	public void setNif(String nif) {
		this.nif = nif;
	}


	public String getNombre() {
		return nombre;
	}


	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


	public int getEdad() {
		return edad;
	}


	public void setEdad(int edad) {
		this.edad = edad;
	}


	public char getSexo() {
		return sexo;
	}


	public void setSexo(char sexo) {
		this.sexo = sexo;
	}


	public float getAltura() {
		return altura;
	}


	public void setAltura(float altura) {
		this.altura = altura;
	}


	public Direccion getDireccion() {
		return direccion;
	}


	public void setDireccion(Direccion direccion) {
		this.direccion = direccion;
	}


	public EstadoCivil getEstado() {
		return estado;
	}


	public void setEstado(EstadoCivil estado) {
		this.estado = estado;
	}


	public String getCurriculum() {
		return curriculum;
	}


	public void setCurriculum(String curriculum) {
		this.curriculum = curriculum;
	}


	@Override
	public String toString() {
		return "Persona [telefono=" + telefono + ", nif=" + nif + ", nombre=" + nombre + ", edad=" + edad + ", sexo="
				+ sexo + ", altura=" + altura + ", direccion=" + direccion + ", estado=" + estado + ", curriculum="
				+ curriculum + "]";
	}
	
}