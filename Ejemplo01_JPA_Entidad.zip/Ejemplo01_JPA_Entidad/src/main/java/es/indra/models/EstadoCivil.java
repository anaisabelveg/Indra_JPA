package es.indra.models;

public enum EstadoCivil{
	
	SOLTERO, CASADO, VIUDO, DIVORCIADO, PAREJA_HECHO;
	
}